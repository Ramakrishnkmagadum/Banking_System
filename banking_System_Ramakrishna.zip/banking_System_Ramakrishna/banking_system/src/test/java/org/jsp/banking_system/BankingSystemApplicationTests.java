package org.jsp.banking_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
