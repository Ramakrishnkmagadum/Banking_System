package org.jsp.banking_system.dto;

import lombok.Data;

@Data
public class Login 
{
int id;
String password;
}